#include <stdio.h>
#include "func1.h"
#include "func2.h"
#include "func3.h"

int main ()
{
    func1();
    func2();
    func3();
    printf (")))0)\n");
    
    return 0;
}

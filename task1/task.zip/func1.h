#include <stdio.h>

#ifndef FUNC1
#define FUNC1

/* func1 выводит строку "Lol"
 */

void func1();

#endif

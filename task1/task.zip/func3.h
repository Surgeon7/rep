#include <stdio.h>

#ifndef FUNC3
#define FUNC3

/* func3 выводит строку "Cheburek"
 */

void func3();

#endif 

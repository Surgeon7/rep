#include <stdio.h>

#ifndef FUNC2
#define FUNC2

/* func2 выводит строку "Kek"
 */

void func2();

#endif 

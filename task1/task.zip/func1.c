#include "func1.h"

void func1 ()
{
    printf ("Lol\n");
}

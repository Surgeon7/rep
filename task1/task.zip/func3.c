#include "func3.h"

void func3 ()
{
    printf ("Cheburek\n");
}

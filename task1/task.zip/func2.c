#include "func2.h"

void func2 ()
{
    printf ("Kek\n");
}
